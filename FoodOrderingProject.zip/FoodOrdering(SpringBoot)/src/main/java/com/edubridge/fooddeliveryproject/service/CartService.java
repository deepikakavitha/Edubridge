package com.edubridge.fooddeliveryproject.service;

import java.util.List;

import com.edubridge.fooddeliveryproject.model.Cart;

public interface CartService {
	//Cart updateCart(Cart cart, String emailID);

	//void deleteCart(String emailID);

	Cart saveCart(Cart cart);

	List<Cart> getCartById();

	Cart getCartById(long cartId);

	void deleteCart(long cartId);
	
	Cart addFoodToCart(Cart cart,long foodId, String getCartByUserEmailId);
	
	List<Cart> getCartByUserEmailId(String userEmailID);

}
