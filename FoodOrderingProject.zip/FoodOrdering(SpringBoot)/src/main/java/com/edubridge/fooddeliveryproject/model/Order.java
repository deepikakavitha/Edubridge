package com.edubridge.fooddeliveryproject.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "Order_Table")
public class Order {
	@Id
	@Column(name = "order_Id")
	@GeneratedValue(generator = "seqo", strategy = GenerationType.IDENTITY)
	@SequenceGenerator(name="seqo", initialValue = 4000)
	public long orderId;
	
	@Column(name = "cart_Id")
	public long cartId;
	
	@Column(name = "total_Price")
	public float totalPrice;
	
	public Order()
	{
		
	}

	public Order(long orderId, long cartId, float totalPrice) {
		super();
		this.orderId = orderId;
		this.cartId = cartId;
		this.totalPrice = totalPrice;
	}

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public long getCartId() {
		return cartId;
	}

	public void setCartId(long cartId) {
		this.cartId = cartId;
	}

	public float getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(float totalPrice) {
		this.totalPrice = totalPrice;
	}


}

