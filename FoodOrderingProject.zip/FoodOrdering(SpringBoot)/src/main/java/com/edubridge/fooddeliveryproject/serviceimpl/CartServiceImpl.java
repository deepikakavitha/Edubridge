package com.edubridge.fooddeliveryproject.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.fooddeliveryproject.exception.UserNotFoundException;
import com.edubridge.fooddeliveryproject.model.Cart;
import com.edubridge.fooddeliveryproject.model.Food;
import com.edubridge.fooddeliveryproject.model.User;
import com.edubridge.fooddeliveryproject.repository.CartRepository;
import com.edubridge.fooddeliveryproject.service.CartService;
import com.edubridge.fooddeliveryproject.service.FoodService;
import com.edubridge.fooddeliveryproject.service.UserService;

@Service
public class CartServiceImpl implements CartService {
	@Autowired
	private CartRepository cartRepository;
    private FoodService foodService;
    private UserService userService;
    

	public CartServiceImpl(CartRepository cartRepository, FoodService foodService, UserService userService) {
		super();
		this.cartRepository = cartRepository;
		this.foodService = foodService;
		this.userService = userService;
	}

	@Override
	public Cart saveCart(Cart cart) {
		// TODO Auto-generated method stub
		return cartRepository.save(cart);
	}

	@Override
	public List<Cart> getCartById() {
		// TODO Auto-generated method stub
		return cartRepository.findAll();
	}

	@Override
	public Cart getCartById(long cartId) {
		// TODO Auto-generated method stub
		return cartRepository.findById(cartId).orElseThrow(()-> new UserNotFoundException("Cart", "cartId",cartId ));
	}

	@Override
	public void deleteCart(long cartId) {
		// TODO Auto-generated method stub
		cartRepository.findById(cartId).orElseThrow(()-> new UserNotFoundException("cart", "cartId", cartId));
		cartRepository.deleteById(cartId);
	}
	
	@Override
	public Cart addFoodToCart(Cart cart, long foodId, String userEmailId) {
		// TODO Auto-generated method stub
		Food food=foodService.getFoodById(foodId);
		User user = userService.getUserByEmailID(userEmailId);
		cart.setUser(user);
		cart.setFood(food);
		return cartRepository.save(cart);
	}

	@Override
	public List<Cart> getCartByUserEmailId(String userEmailID) {
	return 	cartRepository.findByUserEmailID(userEmailID);
		
	}

}
